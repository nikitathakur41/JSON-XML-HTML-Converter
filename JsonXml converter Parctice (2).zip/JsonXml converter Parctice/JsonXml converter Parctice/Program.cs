﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using System.Xml.Linq;
using System.Xml;
using JsonXml_converter_Practice;

namespace JsonXml_converter_Parctice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter the path of the XML file:");
            //string xmlFilePath = Console.ReadLine();

            //// Call the ConvertXmlToHtml method from Class1
            //Class1.ConvertXmlToHtml(xmlFilePath);

            Console.WriteLine("Enter the path of the JSON file:");
            string jsonFilePath = Console.ReadLine();

            // Call the ConvertJsonToXml method from JsonToXml
            JsonToXml.ConvertJsonToXml(jsonFilePath);
        }
    }
}
