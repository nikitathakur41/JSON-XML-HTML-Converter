﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace JsonXml_converter_Parctice
{
    public class JsonToXml
  
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Enter the path of the JSON file:");
                string jsonFilePath = Console.ReadLine();

                ConvertJsonToXml(jsonFilePath);
            }

            static void ConvertJsonToXml(string jsonFilePath)
            {
                try
                {
                    string json = File.ReadAllText(jsonFilePath);
                    JObject jsonObject = JObject.Parse(json);

                    XmlDocument xmlDocument = new XmlDocument();
                    XmlElement root = xmlDocument.CreateElement("Root");
                    xmlDocument.AppendChild(root);

                    BuildXmlFromJson(jsonObject, xmlDocument, root);

                    string xmlFilePath = Path.ChangeExtension(jsonFilePath, "xml");
                    xmlDocument.Save(xmlFilePath);

                    Console.WriteLine("Conversion successful. XML file saved at: " + xmlFilePath);

                    // Optionally, you can call ConvertXmlToHtml here
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error converting JSON to XML: " + ex.Message);
                }
            }

            static void BuildXmlFromJson(JToken token, XmlDocument xmlDocument, XmlElement parent)
            {
                if (token.Type == JTokenType.Object)
                {
                    foreach (var property in token.Children<JProperty>())
                    {
                        XmlElement element = xmlDocument.CreateElement(property.Name);
                        parent.AppendChild(element);
                        BuildXmlFromJson(property.Value, xmlDocument, element);
                    }
                }
                else if (token.Type == JTokenType.Array)
                {
                    foreach (var item in token)
                    {
                        BuildXmlFromJson(item, xmlDocument, parent);
                    }
                }
                else
                {
                    parent.InnerText = token.ToString();
                }
            }
        }
    }

