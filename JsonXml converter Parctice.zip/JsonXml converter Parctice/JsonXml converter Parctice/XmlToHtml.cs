﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Xsl;

namespace JsonXml_converter_Practice
{
    public class Class1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the path of the XML file:");
            string xmlFilePath = Console.ReadLine();

            string html = ConvertXmlToHtml(xmlFilePath);
            if (!string.IsNullOrEmpty(html))
            {
                string htmlFilePath = Path.ChangeExtension(xmlFilePath, "html");
                File.WriteAllText(htmlFilePath, html);
                Console.WriteLine($"HTML file saved at: {htmlFilePath}");
            }
        }

       // static string ConvertXmlToHtml(string xmlFilePath)
            public static void ConvertXmlToHtml(string xmlFilePath)
        {
            try
            {
                StringBuilder htmlBuilder = new StringBuilder();
                htmlBuilder.AppendLine("<ul id=\"tree\" class=\"treeview\">");

                Stack<string> nodeStack = new Stack<string>();
                Stack<bool> hasChildrenStack = new Stack<bool>();
                bool hasChildren = false;

                using (XmlReader reader = XmlReader.Create(xmlFilePath))
                {
                    while (reader.Read())
                    {
                        if (reader.NodeType == XmlNodeType.Element)
                        {
                            string nodeName = reader.Name;
                            nodeStack.Push(nodeName);
                            hasChildren = !reader.IsEmptyElement;
                            hasChildrenStack.Push(hasChildren);

                            htmlBuilder.AppendLine("<li>");
                            htmlBuilder.AppendLine($"<span class=\"caret\">{nodeName}</span>");
                            htmlBuilder.AppendLine("<ul class=\"nested\">");
                        }
                        else if (reader.NodeType == XmlNodeType.EndElement)
                        {
                            htmlBuilder.AppendLine("</ul>");
                            htmlBuilder.AppendLine("</li>");

                            nodeStack.Pop();
                            hasChildrenStack.Pop();
                        }
                        else if (reader.NodeType == XmlNodeType.Text)
                        {
                            if (!string.IsNullOrWhiteSpace(reader.Value))
                            {
                                htmlBuilder.AppendLine($"<li>{reader.Value}</li>");
                            }
                        }
                    }
                }

                while (nodeStack.Count > 0)
                {
                    htmlBuilder.AppendLine("</ul>");
                    htmlBuilder.AppendLine("</li>");
                    nodeStack.Pop();
                    hasChildrenStack.Pop();
                }

                htmlBuilder.AppendLine("</ul>");

                string jsScript = @"
<script>
var toggler = document.getElementsByClassName('caret');
var i;

for (i = 0; i < toggler.length; i++) {
  toggler[i].addEventListener('click', function() {
    this.parentElement.querySelector('.nested').classList.toggle('active');
    this.classList.toggle('caret-down');
  });
}
</script>";

                return htmlBuilder.ToString() + jsScript;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error converting XML to HTML: " + ex.Message);
                return null;
            }
        }
    }
}

